public class Lion extends Mammal {
    @Override
    public void makeNoise() {
        System.out.println("roar");
    }
    public void acceptMammal(Mammal m){
        m.makeNoise(this);
    }
    @Override
    public void makeNoise(Dog d) {
        System.out.println("Lion interacting with dog");
    }
    @Override
    public void makeNoise(Dolphin d) {
        System.out.println("Lion interacting with dolphin");
    }
    @Override
    public void makeNoise(Lion l) {
        System.out.println("Lion interacting with lion");
    }
}
