public class Dolphin extends Mammal {
	
	Dolphin (int lifeSpanYears, int weightKg){
		this.lifeSpanYears = lifeSpanYears;
		this.weightKg = weightKg;
	}
	public void makeNoise() {
		System.out.println("Squeek Click\n");
	}
}
